package functions;

import utility.BitString;
import utility.Converter;
import utility.RandomBitStringGenerator;

import java.util.*;

public class DataCollector {
    FunctionInvokerConfiguration configuration;
    private long minTime, medTime, maxTime;
    private double worstSolution, medSolution, bestSolution;

    public static void main(String[] args) {
        DataCollector dataCollector = new DataCollector();
        Function function = new HomeworkFunction();
        //dataCollector.bazinAcumulareSteepestAscent(function,1,5);
        dataCollector.bazinAcumulareNextAscent(function, 1, 5);
    }

    private static boolean isBetterSolution(double currentSolution, double referenceSolution) {
        return currentSolution < referenceSolution;
    }

    private static boolean hasBiggerValue(double currentSolution, double referenceSolution) {
        return currentSolution > referenceSolution;
    }

    private static boolean isShorter(double currentTime, double referenceTime) {
        return currentTime < referenceTime;
    }

    private static boolean isLonger(double currentTime, double referenceTime) {
        return currentTime > referenceTime;
    }

    private void printImprovement(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        List<BitString> nextAscentCopy = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());

        List<BitString> simulatedAnnealingCopy = new ArrayList<>();
        simulatedAnnealingCopy.addAll(nextAscentCopy);

        HillClimbing climber = new HillClimbing();
        SimulatedAnnealing smith = new SimulatedAnnealing();

        System.out.println(" Next ascent \n");
        climber.runNextAscent(nextAscentCopy, configuration);
        System.out.println();

        System.out.println(" Simulated annealing \n");
        smith.runSimulatedAnnealing(simulatedAnnealingCopy, configuration);

    }

    private void collectDataForFunctionUsingNextAscent(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        initializeData();

        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        HillClimbing climber = new HillClimbing();

        for (int i = 0; i < 30; i++) {
            List<BitString> candidateVariablesInBits;
            candidateVariablesInBits = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());

            long startTime = System.currentTimeMillis();
            double result = climber.runNextAscent(candidateVariablesInBits, configuration);
            long executionTime = System.currentTimeMillis() - startTime;

            medSolution += result;
            collectSolutionData(result);
            medTime += executionTime;
            collectTimeData(executionTime);
        }
        medSolution /= 30;
        medTime /= 30;
    }

    private void bazinAcumulareSteepestAscent(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        initializeData();

        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        HillClimbing climber = new HillClimbing();
        List<Integer> results = new ArrayList();

        for (int i = 0; i < 1000; i++) {
            List<BitString> candidateVariablesInBits;
            candidateVariablesInBits = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());
            List<BitString> save = new ArrayList<>();
            save.addAll(candidateVariablesInBits);
            double result = climber.runSteepestAscent(candidateVariablesInBits, configuration);
            if (result == 4100.0) {
                results.add(Converter.getIntegerFromBitsArray(save.get(0)));
            }
        }
        Collections.sort(results);
        Set<Integer> uniqueResults = new HashSet<Integer>(results);
        for (Integer i : uniqueResults) {
            System.out.println(i);
        }
    }

    private void bazinAcumulareNextAscent(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        initializeData();

        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        HillClimbing climber = new HillClimbing();
        List<Integer> results = new ArrayList();

        for (int i = 0; i < 1000; i++) {
            List<BitString> candidateVariablesInBits;
            candidateVariablesInBits = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());
            List<BitString> save = new ArrayList<>();
            save.addAll(candidateVariablesInBits);
            double result = climber.runNextAscent(candidateVariablesInBits, configuration);
            if (result == 4100.0) {
                results.add(Converter.getIntegerFromBitsArray(save.get(0)));
            }
        }
        Collections.sort(results);
        Set<Integer> uniqueResults = new HashSet<Integer>(results);
        for (Integer i : uniqueResults) {
            System.out.println(i);
        }
    }

    private void collectDataForFunctionUsingSteepestAscent(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        initializeData();

        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        HillClimbing climber = new HillClimbing();

        for (int i = 0; i < 100; i++) {
            System.out.println();
            List<BitString> candidateVariablesInBits;
            candidateVariablesInBits = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());

            long startTime = System.currentTimeMillis();

            double result = climber.runSteepestAscent(candidateVariablesInBits, configuration);
            System.out.println("FINAL SOLUTION: " + result);
            long executionTime = System.currentTimeMillis() - startTime;

            medSolution += result;
            collectSolutionData(result);
            medTime += executionTime;
            collectTimeData(executionTime);
        }
        medSolution /= 30;
        medTime /= 30;
    }

    private void collectDataForFunctionUsingSimulatedAnnealing(Function function, int desiredNumberOfVariables, int desiredPrecision) {
        initializeData();

        configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);

        SimulatedAnnealing climber = new SimulatedAnnealing();

        for (int i = 0; i < 30; i++) {
            List<BitString> candidateVariablesInBits;
            candidateVariablesInBits = RandomBitStringGenerator.getRandomBitStringList(desiredNumberOfVariables, configuration.getNumberOfBits());

            long startTime = System.currentTimeMillis();
            double result = climber.runSimulatedAnnealing(candidateVariablesInBits, configuration);
            //System.out.println(result);
            long executionTime = System.currentTimeMillis() - startTime;

            medSolution += result;
            collectSolutionData(result);
            medTime += executionTime;
            collectTimeData(executionTime);
        }
        medSolution /= 30;
        medTime /= 30;
    }

    private void initializeData() {
        minTime = Long.MAX_VALUE;
        medTime = 0;
        maxTime = Long.MIN_VALUE;
        worstSolution = Double.MIN_VALUE;
        medSolution = 0.0;
        bestSolution = Double.MAX_VALUE;
    }

    void collectTimeData(long executionTime) {
        if (isLonger(minTime, executionTime)) {
            minTime = executionTime;
        }
        if (isShorter(maxTime, executionTime)) {
            maxTime = executionTime;
        }
    }

    void collectSolutionData(double currentSolution) {
        if (hasBiggerValue(currentSolution, worstSolution)) {
            worstSolution = currentSolution;
        }
        if (isBetterSolution(currentSolution, bestSolution)) {
            bestSolution = currentSolution;
        }
    }

    public long getMinTime() {
        return minTime;
    }

    public long getMaxTime() {
        return maxTime;
    }

    public double getWorstSolution() {
        return worstSolution;
    }

    public double getBestSolution() {
        return bestSolution;
    }

    public long getMedTime() {
        return medTime;
    }

    public double getMedSolution() {
        return medSolution;
    }

    void printData() {
        System.out.println();

        System.out.println("Best Solution " + getBestSolution());
        System.out.println("Average Solution: " + getMedSolution());
        System.out.println("Worst Solution " + getWorstSolution());

        System.out.println("Best time in ms: " + getMinTime());
        System.out.println("Average in ms: " + getMedTime());
        System.out.println("Worst time in ms: " + getMaxTime());

        System.out.println();
    }

}
