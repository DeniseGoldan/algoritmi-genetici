package functions;

import utility.ClosedInterval;

import java.util.Collections;
import java.util.List;

public class HomeworkFunction implements Function {
    private static final double DOMAIN_FIRST_ENDPOINT = 0;
    private static final double DOMAIN_SECOND_ENDPOINT = 31;

    @Override
    public double getCalculationResult(List<Double> variables) {

        if (0 == variables.size()) {
            throw new AssertionError("The number of variables must be greater than 0.");
        }
        double x = variables.get(0);
        return Math.pow(x,3) - 60* Math.pow(x,2) + 900 * x + 100;
    }

    @Override
    public String getFunctionName() {
        return "Homework #1' function";
    }

    @Override
    public List<ClosedInterval> getVariablesDomain() {
        return Collections.singletonList(new ClosedInterval(DOMAIN_FIRST_ENDPOINT, DOMAIN_SECOND_ENDPOINT));
    }
}
