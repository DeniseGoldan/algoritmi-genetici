package functions;

import utility.BitString;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * NeighbourGenerator has one static method that, when provided with a candidate list of bitsArray,
 * will return a randomly generated "neighbour" for that candidate. The difference
 * between the candidate and the newly generated "neighbour" is 1 bit (also known as Hamming distance
 * equal to 1). The method uses ThreadLocalRandom to pick a random variable represented in bitsArray
 * and a random index for that variable and negates the chosen bit.
 */
public class NeighbourGenerator {

    public static List<BitString> getNeighbourAtRandomHammingDistanceOfOne(List<BitString> candidate, FunctionInvokerConfiguration configuration) {

        ThreadLocalRandom random = ThreadLocalRandom.current();
        int randomVariableIndex = random.nextInt(0, configuration.getNumberOfVariables());
        int randomBitIndex = random.nextInt(0, configuration.getNumberOfBits());

        List<BitString> neighbour = new ArrayList<>();
        neighbour.addAll(candidate);

        BitString changedVariable = new BitString(candidate.get(randomVariableIndex));
        changedVariable.negateBit(randomBitIndex);
        neighbour.set(randomVariableIndex, changedVariable);

        return neighbour;
    }

    public static List<BitString> getNeighbourWithBitPositionNegated(List<BitString> candidate, int bitPosition) {

        int indexOfVariableToChange = bitPosition / candidate.get(0).getNumberOfBits();
        int indexToNegate = bitPosition % candidate.get(0).getNumberOfBits();

        List<BitString> neighbour = new ArrayList<>();
        neighbour.addAll(candidate);

        BitString changedVariable = new BitString(candidate.get(indexOfVariableToChange));
        changedVariable.negateBit(indexToNegate);
        neighbour.set(indexOfVariableToChange, changedVariable);

        return neighbour;
    }
}
