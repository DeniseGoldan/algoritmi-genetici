package functions;

import utility.BitString;
import utility.Converter;

import java.text.DecimalFormat;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static functions.NeighbourGenerator.getNeighbourAtRandomHammingDistanceOfOne;

public class SimulatedAnnealing {

    public static final int NUMBER_OF_ITERATIONS = 100;

    public double runSimulatedAnnealing(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {
        double candidateResult;
        double neighbourResult;
        List<BitString> neighbourVariablesInBits;

        candidateResult = getFunctionResult(candidateVariablesInBits, configuration);

        double coolingRate = 0.5;
        double minimumTemperature = 0.01;

        for (double temperature = 10; temperature > minimumTemperature; temperature *= coolingRate) {

            for (int i = 0; i < NUMBER_OF_ITERATIONS; i++) {
                neighbourVariablesInBits = getNeighbourAtRandomHammingDistanceOfOne(candidateVariablesInBits, configuration);
                neighbourResult = getFunctionResult(neighbourVariablesInBits, configuration);
                if (candidateResult > neighbourResult) {
                    candidateResult = neighbourResult;
                    candidateVariablesInBits.clear();
                    candidateVariablesInBits.addAll(neighbourVariablesInBits);
                } else {
                    ThreadLocalRandom random = ThreadLocalRandom.current();
                    if (random.nextDouble(0, 1) < Math.exp(-Math.abs((neighbourResult - candidateResult)) / temperature)) {
                        candidateResult = neighbourResult;
                        candidateVariablesInBits.clear();
                        candidateVariablesInBits.addAll(neighbourVariablesInBits);
                    }
                }
                DecimalFormat df = new DecimalFormat("#.000");
                System.out.println(df.format(candidateResult));
            }
        }
        return candidateResult;
    }

    private double getFunctionResult(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {
        double candidateResult;
        candidateResult = configuration.getTargetedFunction().getCalculationResult
                (Converter.getDoubleListFromIntegerList
                        (Converter.getIntegerListFromBitsArrayList
                                (candidateVariablesInBits), configuration.getTargetedFunction().getVariablesDomain().get(0), configuration.getNumberOfBits()));
        return candidateResult;
    }

}

