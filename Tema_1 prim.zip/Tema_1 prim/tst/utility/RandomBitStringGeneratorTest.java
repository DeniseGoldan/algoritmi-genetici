package utility;

import org.junit.Test;

import java.util.List;

/**
 * Created by Denise Goldan on 10/15/2016.
 */
public class RandomBitStringGeneratorTest {
    @Test
    public void getRandomBitsArrayList_returnsAListOfBitsArrayWhenNumberOfVariablesIsPositive() {
        List<BitString> variables = RandomBitStringGenerator.getRandomBitStringList(3,4);
        for (int i = 0; i<3; i++){
            for (int j = 0; j<4; j++){
                System.out.print(variables.get(i).getBit(j)+" ");
            }
            System.out.println();
        }
    }
}