package functions;

import utility.BitString;
import utility.Converter;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class HillClimbing {

    public double runNextAscent(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {

        double candidateResult;
        double neighbourResult;
        List<BitString> neighbourVariablesInBits;
        int length = configuration.getNumberOfBits() * candidateVariablesInBits.size();

        candidateResult = getFunctionResult(candidateVariablesInBits, configuration);

        for (int bitPosition = length - 1; bitPosition >= 0; bitPosition--) {
            neighbourVariablesInBits = NeighbourGenerator.getNeighbourWithBitPositionNegated(candidateVariablesInBits, bitPosition);
            neighbourResult = getFunctionResult(neighbourVariablesInBits, configuration);
            if (neighbourResult < candidateResult) {
                candidateResult = neighbourResult;
                candidateVariablesInBits.clear();
                candidateVariablesInBits.addAll(neighbourVariablesInBits);
                DecimalFormat df = new DecimalFormat("#.000");
                System.out.println(df.format(candidateResult));
            }
        }
        return candidateResult;
    }

    public double runSteepestAscent(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {

        double candidateResult;
        double currentNeighbourResult;
        double bestNeighbourResult = Double.MAX_VALUE;

        List<BitString> currentNeighbourVariablesInBits;
        List<BitString> bestNeighbourVariablesInBits = new ArrayList<>();
        bestNeighbourVariablesInBits.addAll(candidateVariablesInBits);
        int length = configuration.getNumberOfBits() * candidateVariablesInBits.size();

        candidateResult = getFunctionResult(candidateVariablesInBits, configuration);

        boolean decreaseFound = true;
        while (decreaseFound) {
            decreaseFound = false;
            for (int bitPosition = length - 1; bitPosition >= 0; bitPosition--) {

                currentNeighbourVariablesInBits = NeighbourGenerator.getNeighbourWithBitPositionNegated(candidateVariablesInBits, bitPosition);
                currentNeighbourResult = getFunctionResult(currentNeighbourVariablesInBits, configuration);

                if (currentNeighbourResult < bestNeighbourResult) {
                    bestNeighbourResult = currentNeighbourResult;
                    bestNeighbourVariablesInBits.clear();
                    bestNeighbourVariablesInBits.addAll(currentNeighbourVariablesInBits);
                }
            }
            if (bestNeighbourResult < candidateResult) {
                candidateResult = bestNeighbourResult;
                candidateVariablesInBits.clear();
                candidateVariablesInBits.addAll(bestNeighbourVariablesInBits);
                decreaseFound = true;
                DecimalFormat df = new DecimalFormat("#.000");
                System.out.println(df.format(candidateResult));
            }
        }
        return candidateResult;
    }

    private double getFunctionResult(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {
        double candidateResult;
        candidateResult = configuration.getTargetedFunction().getCalculationResult
                (Converter.getDoubleListFromIntegerList
                        (Converter.getIntegerListFromBitsArrayList
                                (candidateVariablesInBits), configuration.getTargetedFunction().getVariablesDomain().get(0), configuration.getNumberOfBits()));
        return candidateResult;
    }


}
