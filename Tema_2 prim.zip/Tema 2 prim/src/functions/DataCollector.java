package functions;

public class DataCollector {
    private double worstSolution, medSolution, bestSolution;

    public static void main(String[] args) {
        //DataCollector.collectDataForDeJong(10,5);
        //DataCollector.collectDataForSchwefel(10,5);
        DataCollector.collectDataForAckley(10,5);
        //DataCollector.collectDataForSixHumpCamelBack(2,5);
    }

    private static void collectDataForDeJong(int desiredNumberOfVariables, int desiredPrecision) {
        Function function = new DeJong();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(1000).
                withFitnessConstant(0).
                withCrossoverProbability(0.8).
                withMutationProbability(0.001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForSchwefel(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new Schwefel();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(1000).
                withFitnessConstant(4000).
                withCrossoverProbability(0.8).
                withMutationProbability(0.001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForAckley(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new Ackley();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(1000).
                withFitnessConstant(0).
                withCrossoverProbability(0.8).
                withMutationProbability(0.001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForSixHumpCamelBack(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new SixHumpCamelBack();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(1000).
                withFitnessConstant(1.75).
                withCrossoverProbability(0.15).
                withMutationProbability(0.001);
        finder.getFinalSolution(configuration);
    }

    private static boolean isBetterSolution(double currentSolution, double referenceSolution) {
        return currentSolution < referenceSolution;
    }

    private static boolean hasBiggerValue(double currentSolution, double referenceSolution) {
        return currentSolution > referenceSolution;
    }

    private static boolean isShorter(double currentTime, double referenceTime) {
        return currentTime < referenceTime;
    }

    private static boolean isLonger(double currentTime, double referenceTime) {
        return currentTime > referenceTime;
    }

    void collectSolutionData(double currentSolution) {
        if (hasBiggerValue(currentSolution, worstSolution)) {
            worstSolution = currentSolution;
        }
        if (isBetterSolution(currentSolution, bestSolution)) {
            bestSolution = currentSolution;
        }
    }

    public double getWorstSolution() {
        return worstSolution;
    }

    public double getBestSolution() {
        return bestSolution;
    }

    public double getMedSolution() {
        return medSolution;
    }

}
