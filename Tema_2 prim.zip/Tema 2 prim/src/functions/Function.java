package functions;

import utility.ClosedInterval;

import java.util.List;

public interface Function {

    String getFunctionName();

    List<ClosedInterval> getVariablesDomain();

    double getCalculationResult(List<Double> variables);
}


