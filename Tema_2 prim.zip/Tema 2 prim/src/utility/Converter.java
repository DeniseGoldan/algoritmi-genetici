package utility;

import java.util.ArrayList;
import java.util.List;

/**
 * The converter uses the Big Endian rule.
 * The most significant bit is on index 0.
 */
public class Converter {
    public static int getIntegerFromBitString(BitString representationInBits) {
        int resultedInteger = 0;
        int numberOfBits = representationInBits.getNumberOfBits();
        for (int i = 0; i < numberOfBits; i++) {
            if (representationInBits.getBit(i)) {
                resultedInteger += Math.pow(2, numberOfBits - i - 1);
            }
        }
        return resultedInteger;
    }

    public static List<Integer> getIntegerListFromBitStringList(List<BitString> representationsInBits) {
        List<Integer> integerList = new ArrayList<>(representationsInBits.size());
        for (int i = 0; i < representationsInBits.size(); i++) {
            //big endian, normal form
            //integerList.add(getIntegerFromBitString(representationsInBits.get(i)));

            ///gray code
            integerList.add(getIntegerFromBitString(getBitRepresentationFromGreyCode(representationsInBits.get(i))));
        }
        return integerList;
    }

    public static BitString getBitRepresentationFromGreyCode(BitString greyCode) {
        BitString convertedGreyCode = new BitString(greyCode.getNumberOfBits());
        convertedGreyCode.setBit(greyCode.getNumberOfBits() - 1, greyCode.getBit(greyCode.getNumberOfBits() - 1));
        for (int bitIndex = greyCode.getNumberOfBits() - 2; bitIndex >= 0; bitIndex--) {
            convertedGreyCode.setBit(bitIndex, convertedGreyCode.getBit(bitIndex + 1) ^ greyCode.getBit(bitIndex));
        }
        return convertedGreyCode;
    }

    public static List<Double> getDoubleListFromIntegerList(List<Integer> integerList, ClosedInterval domain, int numberOfBits) {
        List<Double> doubleList = new ArrayList<>(integerList.size());
        for (Integer current : integerList) {
            doubleList.add(domain.getFirstEndpoint() + (current * (domain.getSecondEndpoint() - domain.getFirstEndpoint()) / (Math.pow(2, numberOfBits) - 1)));
        }
        return doubleList;
    }
}
