package functions;

import org.junit.Test;
import utility.BitString;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 */
public class GeneticAlgorithmTest {
/*    @Test
    public void printCurrentGenerationBest_printsMaxNumberFromArgument() throws Exception {
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(5);
        List<Double> population = new ArrayList<>(5);
        population.add(0.0001);
        population.add(0.0001);
        population.add(0.1001);
        population.add(5.0001);
        population.add(1089.0001);
        assertThat(geneticAlgorithm.getCurrentGenerationSmallestResult(population), is(1089.0001));
    }*/

    @Test
    public void getTotalFitness_returnTheSumOfTheValuesInTheArgument() throws Exception {
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(5);
        List<Double> population = new ArrayList<>(5);
        population.add(0.01);
        population.add(0.02);
        population.add(0.03);
        population.add(1.04);
        population.add(2.05);
        assertThat(geneticAlgorithm.getTotalFitness(population), is(3.15));
    }

    @Test
    public void getIndividualSelectionProbability_returnsTheResultFromDividingEachElementFromFirstArgToSecondArg() throws Exception {
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(5);
        List<Double> population = new ArrayList<>(5);
        List<Double> expectedResults = new ArrayList<>(5);
        population.add(1.0);
        expectedResults.add(1.0 / 17.0);
        population.add(2.0);
        expectedResults.add(2.0 / 17.0);
        population.add(3.0);
        expectedResults.add(3.0 / 17.0);
        population.add(5.0);
        expectedResults.add(5.0 / 17.0);
        population.add(6.0);
        expectedResults.add(6.0 / 17.0);
        assertThat(geneticAlgorithm.getIndividualSelectionProbability(population), is(expectedResults));
    }

    @Test
    public void getMergedSelectionProbability_returnsElementsInAscendingOrder() throws Exception {
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(5);
        List<Double> population = new ArrayList<>(5);
        List<Double> expectedResults = new ArrayList<>(6);
        population.add(1.0);
        expectedResults.add(0.0);
        population.add(2.0);
        expectedResults.add(1.0 / 17.0);
        population.add(3.0);
        expectedResults.add(1.0 / 17.0 + 2.0 / 17.0);
        population.add(5.0);
        expectedResults.add(1.0 / 17.0 + 2.0 / 17.0 + 3.0 / 17.0);
        population.add(6.0);
        expectedResults.add(1.0 / 17.0 + 2.0 / 17.0 + 3.0 / 17.0 + 5.0 / 17.0);
        expectedResults.add(1.0);
        assertThat(geneticAlgorithm.getMergedSelectionProbability(population), is(expectedResults));
    }

    @Test
    public void getInitialPopulation_returnsAListOfChromosomesWithRandomBits() throws Exception {
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        Function function = new DeJong();
        configuration.configureSearch(function, 6, 5);// 6 variables, precision of 5
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm();
        List<List<BitString>> population = geneticAlgorithm.getInitialPopulation(configuration);
        for (int i = 0; i < geneticAlgorithm.getPopulationSize(); i++) {
            System.out.println("Chromosome #" + i);
            for (int j = 0; j < configuration.getNumberOfVariables(); j++) {
                System.out.print("Variable #" + j + ": ");
                for (int k = 0; k < configuration.getNumberOfBits(); k++) {
                    System.out.print(population.get(i).get(j).getBit(k) + " ");
                }
                System.out.println();
            }
            System.out.println();
        }
    }

    @Test
    public void checkWhat_mergedSelectionProbability_ReturnsForAPopulationOf1000() throws Exception {

        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        Function function = new DeJong();
        configuration.configureSearch(function, 6, 5);// 6 variables, precision of 5

        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(1000);
        List<List<BitString>> population = geneticAlgorithm.getInitialPopulation(configuration);
        List<Double> populationFitness = geneticAlgorithm.getPopulationFitness(population, configuration);
        List<Double> mergedSelectionProbability = geneticAlgorithm.getMergedSelectionProbability(populationFitness);

        for (int i = 0; i < geneticAlgorithm.getPopulationSize(); i++) {
            System.out.println(mergedSelectionProbability.get(i) + " corresponds to index " + i);
        }
    }

    @Test
    public void getTotalFitness_returnsTheSumOfDoublesInTheListOfDoublesProvidedAsArgument() throws  Exception{
        List<Double> fitnessResults = new ArrayList<>(5);
        fitnessResults.add(0.00001);
        fitnessResults.add(0.00100);
        fitnessResults.add(0.00020);
        fitnessResults.add(0.00006);
        fitnessResults.add(0.00005);
        double expectedResult = 0.00001 + 0.00100 + 0.00020 + 0.00006 +0.00005;
        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(5);
        assertThat(geneticAlgorithm.getTotalFitness(fitnessResults), is (expectedResult));
    }

    @Test
    public void checkWhat_getSiblingsPairFromSinglePointCrossover_returns() throws Exception{

        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        Function function = new DeJong();
        configuration.configureSearch(function, 6, 5);// 6 variables, precision of 5

        GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm().withPopulationSize(2);
        List<List<BitString>> population = geneticAlgorithm.getInitialPopulation(configuration);
        List<List<BitString>> siblings = geneticAlgorithm.getSiblingsPairFromSinglePointCrossover(population.get(0),population.get(1),configuration);

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j <6 ; j++) {
                for (int k = 0; k < configuration.getNumberOfBits(); k++) {
                    if (population.get(i).get(j).getBit(k)){
                        System.out.print(1);
                    }else {
                        System.out.print(0);
                    }
                }
                System.out.print(" ");
            }
            System.out.println();
        }

        System.out.println();


        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < configuration.getNumberOfVariables(); j++) {
                for (int k = 0; k < configuration.getNumberOfBits(); k++) {
                    if (siblings.get(i).get(j).getBit(k)){
                        System.out.print(1);
                    }else {
                        System.out.print(0);
                    }
                }
                System.out.print(" ");
            }
            System.out.println();
        }

    }
}