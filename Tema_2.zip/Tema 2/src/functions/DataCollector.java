package functions;

public class DataCollector {
    private long minTime, medTime, maxTime;
    private double worstSolution, medSolution, bestSolution;

    public static void main(String[] args) {
        DataCollector.collectDataForDeJong(5,5);
        //DataCollector.collectDataForSchwefel(30,2);
        //DataCollector.collectDataForAckley(30,2);
        //DataCollector.collectDataForSixHumpCamelBack(2,2);
    }

    public static void collectDataForDeJong(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new DeJong();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(15000).
                withFitnessConstant(0).
                withCrossoverProbability(0.8).
                withMutationProbability(0.001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForSchwefel(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new Schwefel();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(1000).
                withFitnessConstant(12000).
                withCrossoverProbability(0.8).
                withMutationProbability(0.0001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForAckley(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new Ackley();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(15000).
                withFitnessConstant(0).
                withCrossoverProbability(0.8).
                withMutationProbability(0.0001);
        finder.getFinalSolution(configuration);
    }

    public static void collectDataForSixHumpCamelBack(int desiredNumberOfVariables, int desiredPrecision) {
        //initializeData();
        Function function = new SixHumpCamelBack();
        FunctionInvokerConfiguration configuration = new FunctionInvokerConfiguration();
        configuration.configureSearch(function, desiredNumberOfVariables, desiredPrecision);
        GeneticAlgorithm finder = new GeneticAlgorithm().
                withPopulationSize(100).
                withNumberOfGenerations(15000).
                withFitnessConstant(1.75).
                withCrossoverProbability(0.15).
                withMutationProbability(0.0001);
        finder.getFinalSolution(configuration);
    }

    private static boolean isBetterSolution(double currentSolution, double referenceSolution) {
        return currentSolution < referenceSolution;
    }

    private static boolean hasBiggerValue(double currentSolution, double referenceSolution) {
        return currentSolution > referenceSolution;
    }

    private static boolean isShorter(double currentTime, double referenceTime) {
        return currentTime < referenceTime;
    }

    private static boolean isLonger(double currentTime, double referenceTime) {
        return currentTime > referenceTime;
    }

    private void initializeData() {
        minTime = Long.MAX_VALUE;
        medTime = 0;
        maxTime = Long.MIN_VALUE;
        worstSolution = Double.MIN_VALUE;
        medSolution = 0.0;
        bestSolution = Double.MAX_VALUE;
    }

    void collectTimeData(long executionTime) {
        if (isLonger(minTime, executionTime)) {
            minTime = executionTime;
        }
        if (isShorter(maxTime, executionTime)) {
            maxTime = executionTime;
        }
    }

    void collectSolutionData(double currentSolution) {
        if (hasBiggerValue(currentSolution, worstSolution)) {
            worstSolution = currentSolution;
        }
        if (isBetterSolution(currentSolution, bestSolution)) {
            bestSolution = currentSolution;
        }
    }

    public long getMinTime() {
        return minTime;
    }

    public long getMaxTime() {
        return maxTime;
    }

    public double getWorstSolution() {
        return worstSolution;
    }

    public double getBestSolution() {
        return bestSolution;
    }

    public long getMedTime() {
        return medTime;
    }

    public double getMedSolution() {
        return medSolution;
    }

    void printData() {
        System.out.println();

        System.out.println("Best Solution " + getBestSolution());
        System.out.println("Average Solution: " + getMedSolution());
        System.out.println("Worst Solution " + getWorstSolution());

        System.out.println("Best time in ms: " + getMinTime());
        System.out.println("Average in ms: " + getMedTime());
        System.out.println("Worst time in ms: " + getMaxTime());

        System.out.println();
    }
}
