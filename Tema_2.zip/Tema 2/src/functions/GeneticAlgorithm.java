package functions;

import utility.BitString;
import utility.Converter;
import utility.RandomBitStringGenerator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static java.lang.Math.floor;

/**
 * You can use Roulette Wheel Selection or Elitism Selection or a combination between those 2.
 * There are multiple operators that you can use.
 */
public class GeneticAlgorithm {

    private int populationSize = 60;
    private double numberOfGenerations = Double.MAX_VALUE;
    private double fitnessConstant = 0;
    private double crossoverProbability = 0.8;
    private double mutationProbability = 0.0001;
    private double elitePercent = 0.13;

    public int getPopulationSize() {
        return populationSize;
    }

    public GeneticAlgorithm withPopulationSize(int desiredPopulationSize) {
        populationSize = desiredPopulationSize;
        return this;
    }

    public GeneticAlgorithm withNumberOfGenerations(int desiredNumberOfGenerations) {
        numberOfGenerations = desiredNumberOfGenerations;
        return this;
    }

    public GeneticAlgorithm withFitnessConstant(double desiredFitnessConstant) {
        fitnessConstant = desiredFitnessConstant;
        return this;
    }
    public GeneticAlgorithm withCrossoverProbability(double desiredCrossoverProbability) {
        crossoverProbability = desiredCrossoverProbability;
        return this;
    }
    public GeneticAlgorithm withMutationProbability(double desiredMutationProbability) {
        mutationProbability = desiredMutationProbability;
        return this;
    }

    public void getFinalSolution(FunctionInvokerConfiguration configuration) {
        if (populationSize < 1) {
            throw new AssertionError("Genetic algorithm not properly initialized. Population Size < 1.\n");
        }
        if (numberOfGenerations < 1) {
            throw new AssertionError("Genetic algorithm not properly initialized. Number of generations < 1.\n");
        }
        if (fitnessConstant < 0) {
            throw new AssertionError("Genetic algorithm not properly initialized. Fitness constant < 1.\n");
        }
        if (mutationProbability == 0) {
            throw new AssertionError("Genetic algorithm not properly initialized. Mutation Probability == 0.\n");
        }
        if (crossoverProbability == 0) {
            throw new AssertionError("Genetic algorithm not properly initialized. Crossover Probability == 0.\n");
        }
        if (configuration.getTargetedFunction() == null) {
            throw new AssertionError("Genetic algorithm not properly initialized. Function is NULL.\n");
        }

        List<List<BitString>> population = getInitialPopulation(configuration);
        runGeneticAlgorithmWithElitismSelection(population, configuration);
    }

    private void runGeneticAlgorithmWithRouletteWheelSelection(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        System.out.println(getCurrentGenerationSmallestResult(population, configuration));
        for (int currentGenerationIndex = 0; currentGenerationIndex < numberOfGenerations; currentGenerationIndex++) {
            population = rouletteWheelPool(population, configuration);
            population = getSingleCutPointCrossoverPopulation(population, configuration);
            population = getMutatedPopulation(population, configuration);
            System.out.println(getCurrentGenerationSmallestResult(population, configuration));
        }
    }

    private void runGeneticAlgorithmWithElitismSelection(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        System.out.println(getCurrentGenerationSmallestResult(population, configuration));
        for (int currentGenerationIndex = 0; currentGenerationIndex < numberOfGenerations; currentGenerationIndex++) {
            List<List<BitString>> elitePopulation = getElitePopulation(population,configuration);
            population = getNoElitePopulation(population, configuration);
            population = rouletteWheelPool(population,configuration);
            population = getSingleCutPointCrossoverPopulation(population, configuration);
            population = getMutatedPopulation(population, configuration);
            population.addAll(elitePopulation);
            System.out.println(getCurrentGenerationSmallestResult(population, configuration));
        }
    }

    private List<List<BitString>> getNoElitePopulation(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        List<List<BitString>> noElitePopulation = new ArrayList<>();
        List<Double> populationFitness = getPopulationFitness(population,configuration);
        Collections.sort(populationFitness);

        double numberOfNoEliteChromosomes = population.size()-floor(population.size()*elitePercent);

        for (int i = 0; i< numberOfNoEliteChromosomes; i++){
            noElitePopulation.add(population.get(i));
        }
        return noElitePopulation;
    }

    private List<List<BitString>> getElitePopulation(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        List<List<BitString>> elitePopulation = new ArrayList<>();
        List<Double> populationFitness = getPopulationFitness(population,configuration);
        Collections.sort(populationFitness);
        Collections.reverse(populationFitness);

        double numberOfEliteChromosomes = floor(population.size()*elitePercent);

        List<Double> eliteFitness = new ArrayList<>();
        for (int i = 0; i<numberOfEliteChromosomes; i++){
            eliteFitness.add(populationFitness.get(i));
            //System.out.println("elite fitness: "+ eliteFitness.get(i));
        }

        for (int i = 0; i< population.size(); i++){
            if (elitePopulation.size()!=numberOfEliteChromosomes &&
                    eliteFitness.contains(getChromosomeFitness(population.get(i),configuration)))
            elitePopulation.add(population.get(i));
        }
        return elitePopulation;
    }

    public List<List<BitString>> getInitialPopulation(FunctionInvokerConfiguration configuration) {
        if (populationSize < 1) {
            throw new AssertionError("Genetic algorithm not properly initialized. Population size < 1.\n");
        }
        List<List<BitString>> population = new ArrayList<>(populationSize);
        for (int i = 0; i < populationSize; i++) {
            population.add(RandomBitStringGenerator.
                    getRandomBitStringList(configuration.getNumberOfVariables(), configuration.getNumberOfBits()));
        }
        return population;
    }

    private double getChromosomeFitness(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {
        double candidateResult;
        candidateResult = configuration.getTargetedFunction().getCalculationResult
                (Converter.getDoubleListFromIntegerList
                        (Converter.getIntegerListFromBitsArrayList
                                (candidateVariablesInBits), configuration.getTargetedFunction().getVariablesDomain().get(0), configuration.getNumberOfBits()));
        return 1/(candidateResult + fitnessConstant);
    }

    public double getCurrentGenerationSmallestResult(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        double bestResult = getCalculationResult(population.get(0), configuration);
        for (int i = 1; i < population.size(); i++) {
            double currentResult = getCalculationResult(population.get(i), configuration);
            if (currentResult < bestResult) {
                bestResult = currentResult;
            }
        }
        return bestResult;
    }

    public double getTotalFitness(List<Double> populationFitness) {
        double result = 0;
        for (int i = 0; i < populationFitness.size(); i++) {
            result += populationFitness.get(i);
        }
        return result;
    }

    public List<Double> getIndividualSelectionProbability(List<Double> populationFitness) {
        double totalFitness = getTotalFitness(populationFitness);
        List<Double> individualSelectionProbability = new ArrayList<>(populationSize);
        for (int i = 0; i < populationFitness.size(); i++) {
            individualSelectionProbability.add(populationFitness.get(i) / totalFitness);
        }
        return individualSelectionProbability;
    }

    /**
     * Returns a list of ascending order doubles from 0.0000 to 1.0000.
     * Each pair of consecutive index values represent the endpoints of a interval as in ( q[i] , q[i+1] ].
     * For a population of size N, in order to have N such intervals, I will need a list of N+1 doubles.
     * In order to later on select an individual j, I will randomly choose a double r such that q[j]< r <= q[j+1],
     * where r in [0, 1].
     */
    public List<Double> getMergedSelectionProbability(List<Double> populationFitness) {
        List<Double> mergedSelectionProbability = new ArrayList<>(populationFitness.size());
        List<Double> individualSelectionProbability = getIndividualSelectionProbability(populationFitness);
        mergedSelectionProbability.add(0.0);
        for (int i = 0; i < populationFitness.size(); i++) {
            mergedSelectionProbability.add(mergedSelectionProbability.get(i) + individualSelectionProbability.get(i));
        }
        return mergedSelectionProbability;
    }

    private List<List<BitString>> rouletteWheelPool(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        List<List<BitString>> selectedChromosomes = new ArrayList<>();
        List<Double> populationFitness = getPopulationFitness(population, configuration);
        List<Double> mergedSelectionProbability = getMergedSelectionProbability(populationFitness);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int tryNumber = 0; tryNumber < population.size(); tryNumber++) {
            double randomNumber = random.nextDouble(0, 1);
            for (int chromosomeIndex = 0; chromosomeIndex < population.size(); chromosomeIndex++) {
                if (mergedSelectionProbability.get(chromosomeIndex) < randomNumber && randomNumber <= mergedSelectionProbability.get(chromosomeIndex + 1)) {
                    selectedChromosomes.add(population.get(chromosomeIndex));
                }
            }
        }
        return selectedChromosomes;
    }

    public List<List<BitString>> getSiblingsPairFromSinglePointCrossover(List<BitString> firstParent, List<BitString> secondParent, FunctionInvokerConfiguration configuration) {

        List<List<BitString>> siblings = new ArrayList<>(2);
        List<BitString> firstSibling = new ArrayList<>();
        List<BitString> secondSibling = new ArrayList<>();

        // parents are equal, return them the way they are, with no modifications
        if (firstParent.equals(secondParent)) {
            siblings.add(firstParent);
            siblings.add(firstParent);
            return siblings;
        }

        ThreadLocalRandom random = ThreadLocalRandom.current();
        int cutPoint = random.nextInt(1, configuration.getNumberOfBits() * configuration.getNumberOfVariables() - 1);

        int numberOfBitsForAVariable = firstParent.get(0).getNumberOfBits();
        int indexOfCutPointVariable = cutPoint / numberOfBitsForAVariable;
        int indexOfCutPointInsideVariable = cutPoint % numberOfBitsForAVariable;

        int numberOfVariables = firstParent.size();

        BitString firstSiblingCutPointVariable = new BitString(numberOfBitsForAVariable);
        BitString secondSiblingCutPointVariable = new BitString(numberOfBitsForAVariable);

        for (int i = 0; i < indexOfCutPointInsideVariable; i++) {
            firstSiblingCutPointVariable.setBit(i, firstParent.get(indexOfCutPointVariable).getBit(i));
            secondSiblingCutPointVariable.setBit(i, secondParent.get(indexOfCutPointVariable).getBit(i));
        }
        for (int i = indexOfCutPointInsideVariable; i < numberOfBitsForAVariable; i++) {
            firstSiblingCutPointVariable.setBit(i, secondParent.get(indexOfCutPointVariable).getBit(i));
            secondSiblingCutPointVariable.setBit(i, firstParent.get(indexOfCutPointVariable).getBit(i));
        }

        for (int i = 0; i < numberOfVariables; i++) {
            if (i < indexOfCutPointVariable) {
                firstSibling.add(firstParent.get(i));
                secondSibling.add(secondParent.get(i));
            } else if (i == indexOfCutPointVariable) {
                firstSibling.add(firstSiblingCutPointVariable);
                secondSibling.add(secondSiblingCutPointVariable);
            } else {
                firstSibling.add(secondParent.get(i));
                secondSibling.add(firstParent.get(i));
            }
        }

        siblings.add(firstSibling);
        siblings.add(secondSibling);
        return siblings;
    }

    private List<List<BitString>> getSingleCutPointCrossoverPopulation(List<List<BitString>> initialPopulation, FunctionInvokerConfiguration configuration) {

        List<List<BitString>> crossoverPopulation = new ArrayList<>(initialPopulation.size());
        crossoverPopulation.addAll(initialPopulation);

        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < initialPopulation.size() - 1; i++) {

            if (random.nextDouble(0, 1) < crossoverProbability) {
                List<List<BitString>> siblings = getSiblingsPairFromSinglePointCrossover(initialPopulation.get(i), initialPopulation.get(i + 1), configuration);
                crossoverPopulation.set(i, siblings.get(0));
                crossoverPopulation.set(i + 1, siblings.get(1));
            }
        }
        return crossoverPopulation;
    }

    private List<List<BitString>> getTwoCutPointsCrossoverPopulation(List<List<BitString>> initialPopulation, FunctionInvokerConfiguration configuration) {

        List<List<BitString>> crossoverPopulation = new ArrayList<>(initialPopulation.size());
        crossoverPopulation.addAll(initialPopulation);

        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < initialPopulation.size() - 1; i++) {

            if (random.nextDouble(0, 1) < crossoverProbability) {
                List<List<BitString>> firstCutSiblings = getSiblingsPairFromSinglePointCrossover(initialPopulation.get(i), initialPopulation.get(i + 1), configuration);
                List<List<BitString>> secondCutSiblings = getSiblingsPairFromSinglePointCrossover(firstCutSiblings.get(0), firstCutSiblings.get(1), configuration);
                crossoverPopulation.set(i, secondCutSiblings.get(0));
                crossoverPopulation.set(i + 1, secondCutSiblings.get(1));

            }
        }
        return crossoverPopulation;
    }

    private List<List<BitString>> getMutatedPopulation(List<List<BitString>> initialPopulation, FunctionInvokerConfiguration configuration) {

        List<List<BitString>> mutatedPopulation = new ArrayList<>(initialPopulation.size());

        ThreadLocalRandom random = ThreadLocalRandom.current();
        int numberOfVariables = configuration.getNumberOfVariables();
        int numberOfBitsForAVariable = configuration.getNumberOfBits();

        for (int chromosomeIndex = 0; chromosomeIndex < initialPopulation.size(); chromosomeIndex++) {

            List<BitString> mutatedChromosome = new ArrayList<>(numberOfVariables);
            for (int variableIndex = 0; variableIndex < numberOfVariables; variableIndex++) {

                BitString mutatedVariable = new BitString(initialPopulation.get(chromosomeIndex).get(variableIndex));
                for (int bitIndex = 0; bitIndex < numberOfBitsForAVariable; bitIndex++) {

                    if (random.nextDouble() < mutationProbability) {
                        mutatedVariable.negateBit(bitIndex);
                    }
                }
                mutatedChromosome.add(mutatedVariable);
            }
            mutatedPopulation.add(mutatedChromosome);
        }
        return mutatedPopulation;
    }

    private double getCalculationResult(List<BitString> candidateVariablesInBits, FunctionInvokerConfiguration configuration) {

        return configuration.getTargetedFunction().getCalculationResult
                (Converter.getDoubleListFromIntegerList
                        (Converter.getIntegerListFromBitsArrayList
                                (candidateVariablesInBits), configuration.getTargetedFunction().getVariablesDomain().get(0), configuration.getNumberOfBits()));
    }

    public List<Double> getPopulationFitness(List<List<BitString>> population, FunctionInvokerConfiguration configuration) {
        List<Double> populationFitness = new ArrayList<>(population.size());
        for (int i = 0; i < population.size(); i++) {
            double currentResult = getChromosomeFitness(population.get(i), configuration);
            populationFitness.add(currentResult);
        }
        return populationFitness;
    }
}

