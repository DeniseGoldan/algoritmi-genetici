package utility;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;


public class RandomBitStringGenerator {

    public static List<BitString> getRandomBitStringList(int numberOfVariables, int numberOfBits) {
        if (numberOfVariables <= 0) {
            throw new AssertionError("The number of variables can not be smaller than 1.");
        }
        if (numberOfBits <= 0) {
            throw new AssertionError("The number of bits used for representing a number can not be smaller than 1.");
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        List<BitString> variables = new ArrayList<>();
        for (int i = 0; i < numberOfVariables; i++) {
            variables.add(getRandomBitString(numberOfBits, random));
        }
        return variables;
    }

    public static BitString getRandomBitString(int numberOfBits, ThreadLocalRandom random){
        BitString representationInBits = new BitString(numberOfBits);
        for (int j = 0; j < numberOfBits; j++) {
            representationInBits.setBit(j, random.nextBoolean());
        }
        return representationInBits;
    }

}
