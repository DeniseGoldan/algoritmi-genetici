import org.dom4j.DocumentException;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DataCollector {
    private double worstSolution, bestSolution;

    public static void main(String[] args) throws DocumentException {

        Path test_1 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\burma14.xml");
        Path test_2 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\bayg29.xml");
        Path test_3 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\gr21.xml");
        Path test_4 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\ezz.xml");
        Path test_5 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\dantzig42.xml");
        Path test_6 = Paths.get("C:\\Users\\Denise Goldan\\Documents\\Workspace\\algoritmi-genetici\\Tema_3 TSP\\eil51.xml");


        DataCollector collector = new DataCollector();
        //collector.collectDataFor(test_1);
        //collector.collectDataFor(test_2);
        //collector.collectDataFor(test_3);
        //collector.collectDataFor(test_4);
        collector.collectDataFor(test_5);
        //collector.collectDataFor(test_6);
    }

    private static boolean isBetterSolution(double currentSolution, double referenceSolution) {
        return currentSolution < referenceSolution;
    }

    private static boolean hasBiggerValue(double currentSolution, double referenceSolution) {
        return currentSolution > referenceSolution;
    }


    public void collectDataFor(Path filename) throws DocumentException {
        PathFinder finder = new PathFinder();
        File file = new File(String.valueOf(filename));
        TSPInstanceGetter instance = new TSPInstanceGetter(file);

        finder.withInstance(instance).
                withPopulationSize(150).
                withNumberOfGenerations(15000).
                withMutationProbability(0.05).
                withCrossoverProbability(0.65);

        initializeData();

        for (int i = 0; i<1; i++){
            finder.getFinalSolution();
            collectSolutionData(finder.getSmallestCost());
        }

        printData();
        //finder.getFinalSolution();
        //System.out.println(finder.getSmallestCost());
        //finder.printBestPath();
    }

    private void initializeData() {
        worstSolution = Double.MIN_VALUE;
        bestSolution = Double.MAX_VALUE;
    }


    void collectSolutionData(double currentSolution) {
        if (hasBiggerValue(currentSolution, worstSolution)) {
            worstSolution = currentSolution;
        }
        if (isBetterSolution(currentSolution, bestSolution)) {
            bestSolution = currentSolution;
        }
    }

    public double getWorstSolution() {
        return worstSolution;
    }

    public double getBestSolution() {
        return bestSolution;
    }

    void printData() {
        System.out.println();

        System.out.println("Best Solution " + getBestSolution());
        System.out.println("Worst Solution " + getWorstSolution());

        System.out.println();
    }
}
