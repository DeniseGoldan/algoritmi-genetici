import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class PathFinder {

    private double smallestCost = Double.MAX_VALUE;

    public void printBestPath(){
        System.out.print("Best path: ");
        for (int i = 0; i< bestPath.size(); i++){
            System.out.print(bestPath.get(i)+" ");
        }
    }

    private List<Integer> bestPath = new ArrayList<>();
    private TSPInstanceGetter instance;
    private int populationSize;
    private int numberOfGenerations;
    private double mutationProbability;
    private double crossoverProbability;

    public void getFinalSolution() {
        if (populationSize < 1) {
            throw new AssertionError("Genetic algorithm not properly initialized. Population Size < 1.\n");
        }
        if (numberOfGenerations < 1) {
            throw new AssertionError("Genetic algorithm not properly initialized. Number of generations < 1.\n");
        }

        if (mutationProbability == 0) {
            throw new AssertionError("Genetic algorithm not properly initialized. Mutation Probability == 0.\n");
        }
        if (crossoverProbability == 0) {
            throw new AssertionError("Genetic algorithm not properly initialized. Crossover Probability == 0.\n");
        }
        List<List<Integer>> population = PermutationsGenerator.getInitialPopulation(populationSize, instance.getNumberOfCities());
        runGeneticAlgorithmWithRouletteWheelSelection(population);
    }

    private void runGeneticAlgorithmWithRouletteWheelSelection(List<List<Integer>> population) {
        updateSmallestCostAndCorrespondingPath(population);
        for (int currentGenerationIndex = 0; currentGenerationIndex < numberOfGenerations; currentGenerationIndex++) {
            population = rouletteWheelPool(population);
            population = getSingleCutCrossoverPopulation(population);
            population = getMutatedPopulation(population);
            updateSmallestCostAndCorrespondingPath(population);
        }
    }

    public void updatePathCorrespondingToSmallestCost(List<List<Integer>> population) {
        List<Integer> currentBestPath = new ArrayList<>();
        for (int i = 0; i < population.size(); i++) {
            if (getChromosomeCost(population.get(i)) == smallestCost) {
                for (int j = 0; j < instance.getNumberOfCities(); j++) {
                    currentBestPath.add(population.get(i).get(j));
                }
                if (!bestPath.isEmpty()){
                    bestPath.clear();
                }
                bestPath.addAll(currentBestPath);
                break;
            }
        }
    }

    public double getCurrentGenerationSmallestCost(List<List<Integer>> population) {
        double bestResult = getChromosomeCost(population.get(0));
        for (int i = 1; i < population.size(); i++) {
            double currentResult = getChromosomeCost(population.get(i));
            if (currentResult < bestResult) {
                bestResult = currentResult;
            }
        }
        return bestResult;
    }

    public void updateSmallestCostAndCorrespondingPath(List<List<Integer>> population) {
        double bestResult = getCurrentGenerationSmallestCost(population);
        // Update smallest result of all times
        if (smallestCost > bestResult) {
            smallestCost = bestResult;
        }
        //Update best path
        updatePathCorrespondingToSmallestCost(population);
    }

    public double getCurrentGenerationBestFitnessResult(List<List<Integer>> population) {
        double bestResult = getChromosomeFitness(population.get(0));
        for (int i = 1; i < population.size(); i++) {
            double currentResult = getChromosomeFitness(population.get(i));
            if (currentResult > bestResult) {
                bestResult = currentResult;
            }
        }
        return bestResult;
    }

    public double getTotalFitness(List<Double> populationFitness) {
        double result = 0;
        for (int i = 0; i < populationFitness.size(); i++) {
            result += populationFitness.get(i);
        }
        return result;
    }

    public List<Double> getIndividualSelectionProbability(List<Double> populationFitness) {
        double totalFitness = getTotalFitness(populationFitness);
        List<Double> individualSelectionProbability = new ArrayList<>(populationFitness.size());
        for (int i = 0; i < populationFitness.size(); i++) {
            individualSelectionProbability.add(populationFitness.get(i) / totalFitness);
        }
        return individualSelectionProbability;
    }

    /**
     * Returns a list of ascending order doubles from 0.0000 to 1.0000.
     * Each pair of consecutive index values represent the endpoints of a interval as in ( q[i] , q[i+1] ].
     * For a population of size N, in order to have N such intervals, I will need a list of N+1 doubles.
     * In order to later on select an individual j, I will randomly choose a double r such that q[j]< r <= q[j+1],
     * where r in [0, 1].
     */
    public List<Double> getMergedSelectionProbability(List<Double> populationFitness) {
        List<Double> mergedSelectionProbability = new ArrayList<>(populationFitness.size());
        List<Double> individualSelectionProbability = getIndividualSelectionProbability(populationFitness);
        mergedSelectionProbability.add(0.0);
        for (int i = 0; i < populationFitness.size(); i++) {
            mergedSelectionProbability.add(mergedSelectionProbability.get(i) + individualSelectionProbability.get(i));
        }
        return mergedSelectionProbability;
    }

    private List<List<Integer>> rouletteWheelPool(List<List<Integer>> population) {
        List<List<Integer>> selectedChromosomes = new ArrayList<>();
        List<Double> populationFitness = getPopulationFitness(population);
        List<Double> mergedSelectionProbability = getMergedSelectionProbability(populationFitness);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int tryNumber = 0; tryNumber < population.size(); tryNumber++) {
            double randomNumber = random.nextDouble(0, 1);
            for (int chromosomeIndex = 0; chromosomeIndex < population.size(); chromosomeIndex++) {
                if (mergedSelectionProbability.get(chromosomeIndex) < randomNumber &&
                        randomNumber <= mergedSelectionProbability.get(chromosomeIndex + 1)) {
                    selectedChromosomes.add(population.get(chromosomeIndex));
                }
            }
        }
        return selectedChromosomes;
    }

    public double getChromosomeFitness(List<Integer> currentPath) {
        if (getChromosomeCost(currentPath) != 0) {
            return 1 / getChromosomeCost(currentPath);
        }
        return 0;
    }

    public double getChromosomeCost(List<Integer> currentPath) {
        double pathCost = 0;
        for (int i = 0; i <= currentPath.size() - 2; i++) {
            pathCost += instance.getDistanceBetween(currentPath.get(i), currentPath.get(i + 1));
        }
        pathCost += instance.getDistanceBetween(currentPath.get(currentPath.size() - 1), currentPath.get(0));
        return pathCost;
    }

    public List<Double> getPopulationFitness(List<List<Integer>> population) {
        List<Double> populationFitness = new ArrayList<>(population.size());
        for (int i = 0; i < population.size(); i++) {
            double currentResult = getChromosomeFitness(population.get(i));
            populationFitness.add(currentResult);
        }
        return populationFitness;
    }

    List<List<Integer>> getMutatedPopulation(List<List<Integer>> initialPopulation) {
        List<List<Integer>> mutatedPopulation = new ArrayList<>(initialPopulation.size());
        mutatedPopulation.addAll(initialPopulation);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int chromosomeIndex = 0; chromosomeIndex < initialPopulation.size(); chromosomeIndex++) {
            if (random.nextDouble(0, 1) < mutationProbability) {
                mutatedPopulation.set(chromosomeIndex, getMutatedPermutation(initialPopulation.get(chromosomeIndex)));
            }
        }
        return mutatedPopulation;
    }


    List<List<Integer>> getSingleCutCrossoverPopulation(List<List<Integer>> initialPopulation) {
        List<List<Integer>> crossoverPopulation = new ArrayList<>(initialPopulation.size());
        crossoverPopulation.addAll(initialPopulation);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < initialPopulation.size() - 1; i++) {
            if (random.nextDouble(0, 1) < crossoverProbability) {

                List<List<Integer>> siblings = getSiblingsFromSinglePointCrossover
                        (initialPopulation.get(i), initialPopulation.get(i + 1));

                crossoverPopulation.set(i, siblings.get(0));
                crossoverPopulation.set(i + 1, siblings.get(1));
            }
        }
        return crossoverPopulation;
    }

    List<List<Integer>> getTwoCutPointsCrossoverPopulation(List<List<Integer>> initialPopulation) {
        List<List<Integer>> crossoverPopulation = new ArrayList<>(initialPopulation.size());
        crossoverPopulation.addAll(initialPopulation);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (int i = 0; i < initialPopulation.size() - 1; i++) {
            if (random.nextDouble(0, 1) < crossoverProbability) {

                List<List<Integer>> firstCutSiblings = getSiblingsFromSinglePointCrossover
                        (initialPopulation.get(i), initialPopulation.get(i + 1));

                List<List<Integer>> secondCutSiblings = getSiblingsFromSinglePointCrossover
                        (firstCutSiblings.get(0), firstCutSiblings.get(1));

                crossoverPopulation.set(i, secondCutSiblings.get(0));
                crossoverPopulation.set(i + 1, secondCutSiblings.get(1));
            }
        }
        return crossoverPopulation;
    }

    public List<Integer> getMutatedPermutation(List<Integer> currentPermutation) {
        ThreadLocalRandom randomIndex = ThreadLocalRandom.current();
        int firstIndex = randomIndex.nextInt(2, currentPermutation.size() - 1);
        int secondIndex = randomIndex.nextInt(2, currentPermutation.size() - 1);

        List<Integer> mutatedPermutation = new ArrayList<>();
        mutatedPermutation.addAll(currentPermutation);

        int temporary = mutatedPermutation.get(firstIndex);
        mutatedPermutation.set(firstIndex, mutatedPermutation.get(secondIndex));
        mutatedPermutation.set(secondIndex, temporary);

        return mutatedPermutation;
    }

    public List<List<Integer>> getSiblingsFromSinglePointCrossover(List<Integer> firstParent, List<Integer> secondParent) {
        List<List<Integer>> siblings = new ArrayList<>();
        List<Integer> firstChild = new ArrayList<>();
        List<Integer> secondChild = new ArrayList<>();

        int numberOfCitites = firstParent.size();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int randomCutPoint = random.nextInt(2, numberOfCitites - 1);

        // Copy the city indexes from 0 to randomCutPoint-1
        for (int cityIndex = 0; cityIndex < randomCutPoint; cityIndex++) {
            firstChild.add(secondParent.get(cityIndex));
            secondChild.add(firstParent.get(cityIndex));
        }

        // Check if the parent ([first/]second parent corresponds to [second/]first child)
        // has valid elements to include from randomCutPoint to numberOfCities
        for (int cityIndex = randomCutPoint; cityIndex < numberOfCitites; cityIndex++) {
            if (!firstChild.contains(firstParent.get(cityIndex))) {
                firstChild.add(firstParent.get(cityIndex));
            }
            if (!secondChild.contains(secondParent.get(cityIndex))) {
                secondChild.add(secondParent.get(cityIndex));
            }
        }

        // Add unvisited citites
        for (int cityIndex = 0; cityIndex < numberOfCitites; cityIndex++) {
            if (!firstChild.contains(cityIndex)) {
                firstChild.add(cityIndex);
            }
            if (!secondChild.contains(cityIndex)) {
                secondChild.add(cityIndex);
            }
        }

        siblings.add(firstChild);
        siblings.add(secondChild);
        return siblings;
    }

    public int getPopulationSize() {
        return populationSize;
    }

    public int getNumberOfGenerations() {
        return numberOfGenerations;
    }

    public double getMutationProbability() {
        return mutationProbability;
    }

    public double getCrossoverProbability() {
        return crossoverProbability;
    }

    public PathFinder withPopulationSize(int populationSize) {
        this.populationSize = populationSize;
        return this;
    }

    public PathFinder withNumberOfGenerations(int numberOfGenerations) {
        this.numberOfGenerations = numberOfGenerations;
        return this;

    }

    public PathFinder withMutationProbability(double mutationProbability) {
        this.mutationProbability = mutationProbability;
        return this;
    }

    public PathFinder withCrossoverProbability(double crossoverProbability) {
        this.crossoverProbability = crossoverProbability;
        return this;
    }

    public PathFinder withInstance(TSPInstanceGetter instance) {
        this.instance = instance;
        return this;
    }

    public TSPInstanceGetter getInstance() {
        return instance;
    }


    public double getSmallestCost() {
        return smallestCost;
    }
}
