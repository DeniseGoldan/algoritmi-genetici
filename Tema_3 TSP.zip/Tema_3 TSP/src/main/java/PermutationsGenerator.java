import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PermutationsGenerator {

    public static List<List<Integer>> getInitialPopulation(int populationSize, int numberOfCities) {
        assert (populationSize > 1);
        assert (numberOfCities > 1);
        List<List<Integer>> population = new ArrayList<>();
        List<Integer> canonicPermutation = getCanonicPermutation(numberOfCities);
        for (int index = 0; index < populationSize; index++) {
            population.add(shufflePermutation(canonicPermutation));
        }
        return population;
    }

    /**
     * The canonic permutation of length 10 is : 0 1 2 3 4 5 6 7 8 9
     * */
    public static List<Integer> getCanonicPermutation(int numberOfCities) {
        List<Integer> canonicPermutation = new ArrayList<>();
        for (int index = 0; index < numberOfCities; index++) {
            canonicPermutation.add(index);
        }
        return canonicPermutation;
    }

    static List<Integer> shufflePermutation(List<Integer> currentPermutation) {
        List<Integer> shuffledPermutation = new ArrayList<>();
        shuffledPermutation.addAll(currentPermutation);
        Collections.shuffle(shuffledPermutation);
        return shuffledPermutation;
    }

}
