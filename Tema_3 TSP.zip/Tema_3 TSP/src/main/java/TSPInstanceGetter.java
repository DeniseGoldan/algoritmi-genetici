import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.Iterator;


public class TSPInstanceGetter {

    private int numberOfCities;
    private double[][] distancesMatrix;

    public TSPInstanceGetter(File fileName) throws DocumentException {
        try {
            SAXReader reader = new SAXReader();
            Document document = reader.read(fileName);
            Element graph = document.getRootElement().element("graph");

            // Avoiding Null Pointer Exception means initialising the distance matrix
            // We must count the child tags under the "graph" root
            int count = 0;
            for (Iterator i = graph.elementIterator(); i.hasNext(); ) {
                Element e = (Element) i.next();
                count++;
            }
            numberOfCities = count;
            distancesMatrix = new double[count][count];

            // Fill in the adjacency matrix that stores the cost corresponding to distance(start, finish)
            int startIndex = 0;
            for (Iterator i = graph.elementIterator(); i.hasNext(); ) {

                Element start = (Element) i.next();
                for (Iterator j = start.elementIterator(); j.hasNext(); ) {

                    Element finish = (Element) j.next();
                    int finishIndex = Integer.valueOf(finish.getText());
                    double cost = Double.valueOf(finish.attributeValue("cost"));

                    distancesMatrix[startIndex][finishIndex] = cost;
                    distancesMatrix[finishIndex][startIndex] = cost;
                }
                startIndex++;
            }

        } catch (DocumentException e) {
            e.printStackTrace();
        }

    }

    public int getNumberOfCities() {
        return numberOfCities;
    }

    public double getDistanceBetween(int start, int finish) {
        return distancesMatrix[start][finish];
    }
}
