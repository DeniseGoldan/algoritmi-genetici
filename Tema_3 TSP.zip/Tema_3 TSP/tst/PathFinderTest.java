import org.junit.Test;

import java.util.List;

public class PathFinderTest {

    @Test
    public void mutatePermutation_swapsTwoGenes() {
        System.out.println("Checking mutation...");
        List<Integer> canonicPermutation = PermutationsGenerator.getCanonicPermutation(10);
        List<Integer> shuffledPermutation = PermutationsGenerator.shufflePermutation(canonicPermutation);
        for (int index = 0; index < shuffledPermutation.size(); index++) {
            System.out.print(shuffledPermutation.get(index) + " ");
        }
        System.out.println();

        PathFinder finder = new PathFinder();
        List<Integer> mutatedPermutation = finder.getMutatedPermutation(shuffledPermutation);
        for (int index = 0; index < mutatedPermutation.size(); index++) {
            System.out.print(mutatedPermutation.get(index) + " ");
        }

        System.out.println();
    }

    @Test
    public void checkWhat_getSiblingsPairFromSinglePointCrossover_returns() throws Exception {
        System.out.println("Siblings pair...");
        List<Integer> canonicPermutation = PermutationsGenerator.getCanonicPermutation(10);
        List<Integer> firstParent = PermutationsGenerator.shufflePermutation(canonicPermutation);
        List<Integer> secondParent = PermutationsGenerator.shufflePermutation(canonicPermutation);

        for (int index = 0; index < 10; index++) {
            System.out.print(firstParent.get(index) + " ");
        }
        System.out.println();
        for (int index = 0; index < 10; index++) {
            System.out.print(secondParent.get(index) + " ");
        }
        System.out.println();

        PathFinder finder = new PathFinder();
        List<List<Integer>> siblings = finder.getSiblingsFromSinglePointCrossover(firstParent, secondParent);

        for (int index = 0; index < 10; index++) {
            System.out.print(siblings.get(0).get(index) + " ");
        }
        System.out.println();
        for (int index = 0; index < 10; index++) {
            System.out.print(siblings.get(1).get(index) + " ");
        }
        System.out.println();
    }
    @Test
    public void nimic(){
        System.out.print(Math.sqrt(111));
    }
}
