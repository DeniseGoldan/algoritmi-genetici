import org.dom4j.io.SAXReader;
import org.junit.Test;

import java.util.List;

public class PermutationsGeneratorTest {

    @Test
    public void getInitialPopulation_returnsAListOfPermutations() {
        System.out.println("Getting initial population of size 10 with 5 cities...");
        int populationSize = 10;
        int numberOfCities = 5;
        List<List<Integer>> population = PermutationsGenerator.getInitialPopulation(populationSize, numberOfCities);
        for (int chromosomeIndex = 0; chromosomeIndex < populationSize; chromosomeIndex++) {
            for (int geneIndex = 0; geneIndex < numberOfCities; geneIndex++) {
                System.out.print(population.get(chromosomeIndex).get(geneIndex) + " ");
            }
            System.out.println();
        }
    }

    @Test
    public void shufflePermutation_returnsADifferentPermutation() {
        System.out.println("Shuffling a canonic permutation of size 5...");
        List<Integer> canonicPermutation = PermutationsGenerator.getCanonicPermutation(5);
        List<Integer> shuffledPermutation;
        shuffledPermutation = PermutationsGenerator.shufflePermutation(canonicPermutation);
        for (int index = 0; index < canonicPermutation.size(); index++) {
            System.out.print(canonicPermutation.get(index) + " ");
        }
        System.out.println();
        for (int index = 0; index < shuffledPermutation.size(); index++) {
            System.out.print(shuffledPermutation.get(index) + " ");
        }
        System.out.println();
    }

}