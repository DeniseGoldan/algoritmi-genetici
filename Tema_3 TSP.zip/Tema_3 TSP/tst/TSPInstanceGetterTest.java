import org.dom4j.DocumentException;
import org.junit.Test;

import java.io.File;
import java.nio.file.Paths;

import static junit.framework.TestCase.assertEquals;


public class TSPInstanceGetterTest {

    @Test
    public void checkIfObtainedPathHasCorrectCostPrinted() throws Exception{
        File file = new File("bayg29.xml");
        TSPInstanceGetter instance = new TSPInstanceGetter(file);
        double sum = 0;
        sum += instance.getDistanceBetween(26,7)+instance.getDistanceBetween(7,11)+
                instance.getDistanceBetween(11,5)+instance.getDistanceBetween(5,8)+
                instance.getDistanceBetween(8,4)+instance.getDistanceBetween(4,28)+
                instance.getDistanceBetween(28,25)+instance.getDistanceBetween(25,2)+
                instance.getDistanceBetween(2,10)+instance.getDistanceBetween(10,21)+
                instance.getDistanceBetween(21,16)+instance.getDistanceBetween(16,13)+
                instance.getDistanceBetween(13,17)+instance.getDistanceBetween(17,19)+
                instance.getDistanceBetween(19,1)+instance.getDistanceBetween(1,20)+
                instance.getDistanceBetween(20,9)+instance.getDistanceBetween(9,3)+
                instance.getDistanceBetween(3,14)+instance.getDistanceBetween(14,18)+
                instance.getDistanceBetween(18,24)+instance.getDistanceBetween(24,6)+
                instance.getDistanceBetween(6,22)+instance.getDistanceBetween(22,15)+
                instance.getDistanceBetween(15,12)+instance.getDistanceBetween(12,0)+
                instance.getDistanceBetween(0,27)+instance.getDistanceBetween(27,23)+
                instance.getDistanceBetween(23,26);
        assertEquals(2021.0,sum );
    }

    @Test
    public void printAdjacencyMatrixForBayg29() throws DocumentException{
        File file = new File("bayg29.xml");
        TSPInstanceGetter instance = new TSPInstanceGetter(file);

        for (int i = 0; i< instance.getNumberOfCities(); i++){
            for(int j = 0; j<instance.getNumberOfCities(); j++){
                System.out.print(instance.getDistanceBetween(i,j)+" ");
            }
            System.out.println();
        }
    }

    @Test
    public void getDistanceBetween_returnsCorrectDistanceBetweenProvidedArguments() throws DocumentException {
        File file = new File("ezz.xml");
        TSPInstanceGetter instance = new TSPInstanceGetter(file);
        assertEquals (1.0, instance.getDistanceBetween(0,1) );
        assertEquals (9.0, instance.getDistanceBetween(0,2) );
        assertEquals (4.0, instance.getDistanceBetween(0,3) );
        assertEquals (2.0, instance.getDistanceBetween(1,2) );

        for (int i = 0; i< instance.getNumberOfCities(); i++){
            for(int j = 0; j<instance.getNumberOfCities(); j++){
                System.out.print(instance.getDistanceBetween(i,j)+" ");
            }
            System.out.println();
        }
    }

    @Test (expected = junit.framework.AssertionFailedError.class)
    public void assertEqualsthrowsExceptionWhen_getDistanceBetween_IsComparedToIncorrectValues() throws DocumentException {
        File file = new File("bayg29.xml");
        TSPInstanceGetter instance = new TSPInstanceGetter(file);
        assertEquals (9.70008800000e+01, instance.getDistanceBetween(0,1) );
        assertEquals (22, instance.getDistanceBetween(0,1) );
    }

    @Test
    public void getNumberOfCities_returnsCorrectNumberOfCities() throws DocumentException {
        File file = new File("bayg29.xml");
        TSPInstanceGetter instance = new TSPInstanceGetter(file);
        assertEquals (29, instance.getNumberOfCities() );
    }

}
